import re

def extract_numeric(text):
    """Helper function to extract numeric values from text."""
    match = re.search(r'\d+(\.\d+)?', text)  # Search for a pattern that matches a number
    return match.group().replace('p', '') if match else ''  # Return the matched number or an empty string if no match is found

def calculate_medians(worksheet):
    """Calculate medians for the numerical columns and add them below the AVERAGE row."""
    values = worksheet.get_all_values()
    num_rows = len(values)
    num_cols = len(values[0])

    if num_rows > 1:
        annual_medians = ['', '', "ANNUAL MEDIAN"]
        for col in range(3, num_cols):
            col_values = sorted([float(extract_numeric(values[row][col])) for row in range(1, num_rows) if extract_numeric(values[row][col])])
            if col_values:
                if col == 3:  # Assuming the Year is in the 4th column (index 3)
                    median = int(col_values[len(col_values) // 2])  # Convert the median year to an integer
                    annual_medians.append(str(median))  # Ensure it's a string
                else:
                    median = col_values[len(col_values) // 2]
                    annual_medians.append(f"{median:.2f}")
            else:
                annual_medians.append("")

        # Add the new annual median row
        worksheet.append_row(annual_medians)
        
        # Apply bold format to the "ANNUAL MEDIAN" row
        median_row_index = len(values) + 1  # New row index after appending
        cell_range = f'A{median_row_index}:Z{median_row_index}'  # Adjust the range as needed
        fmt = {
            "textFormat": {
                "bold": True
            }
        }
        worksheet.format(cell_range, fmt)
