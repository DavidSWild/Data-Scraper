import pandas as pd
from scipy.stats import skew

def calculate_annual_skew(worksheet):
    """Calculate and append the skewness of each numeric column in the worksheet."""
    rows = worksheet.get_all_values()
    if not rows:
        print("No data found in worksheet.")
        return

    headers = rows[0]
    if len(headers) < 3:
        print(f"Unexpected headers length: {len(headers)}. Headers: {headers}")
        return

    data = rows[1:]

    # Convert data to a DataFrame
    df = pd.DataFrame(data, columns=headers)

    # Remove non-numeric rows like 'ANNUAL AVERAGE', 'ANNUAL MEDIAN', etc.
    summary_labels = ["ANNUAL AVERAGE", "ANNUAL MEDIAN", "ANNUAL RANGE", "ANNUAL STANDARD DEVIATION", "ANNUAL VARIANCE", "ANNUAL IQR", "ANNUAL MAD", "ANNUAL SKEW"]
    df = df[~df[headers[2]].isin(summary_labels)]

    # Convert numeric columns to floats
    numeric_columns = df.columns[4:]
    df[numeric_columns] = df[numeric_columns].apply(pd.to_numeric, errors='coerce')

    # Calculate skewness for each numeric column
    skew_values = df[numeric_columns].apply(lambda x: round(skew(x.dropna()), 4), axis=0)

    # Replace NaN values with 0 or any other appropriate value
    skew_values = skew_values.fillna(0)

    # Append the skewness row
    skew_row = [""] * 4 + skew_values.tolist()
    skew_row[2] = "ANNUAL SKEW"
    worksheet.append_row(skew_row)

    # Apply bold format to the "ANNUAL SKEW" row
    cell_range = f"A{len(rows) + 1}:Z{len(rows) + 1}"  # Adjust the range as needed
    fmt = {
        "textFormat": {
            "bold": True
        }
    }
    worksheet.format(cell_range, fmt)
