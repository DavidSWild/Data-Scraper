import pandas as pd
import numpy as np

def calculate_median_absolute_deviation(worksheet):
    """Calculate Median Absolute Deviation (MAD) for the numerical columns and add them to the bottom of the worksheet."""
    values = worksheet.get_all_values()
    num_rows = len(values)
    num_cols = len(values[0])

    if num_rows > 1:
        mad_row = ['', '', "ANNUAL MAD", worksheet.title]
        
        for col in range(4, num_cols):
            col_values = [float(values[row][col]) for row in range(1, num_rows) if values[row][col] and values[row][2] not in ["ANNUAL AVERAGE", "ANNUAL MEDIAN", "ANNUAL RANGE", "ANNUAL STANDARD DEVIATION", "ANNUAL VARIANCE", "ANNUAL IQR"]]
            if col_values:
                median = np.median(col_values)
                mad = np.median([np.abs(x - median) for x in col_values])
                mad_row.append(f"{mad:.2f}")
            else:
                mad_row.append("")

        # Remove existing MAD row if it exists
        existing_rows = worksheet.get_all_values()
        while existing_rows and (existing_rows[-1][2] == "ANNUAL MAD"):
            worksheet.delete_rows(len(existing_rows))
            existing_rows = worksheet.get_all_values()

        # Add the new MAD row
        worksheet.append_row(mad_row)
        
        # Apply bold format to the "ANNUAL MAD" row
        mad_row_index = len(existing_rows) + 1  # New row index after appending
        cell_range = f'A{mad_row_index}:Z{mad_row_index}'  # Adjust the range as needed
        fmt = {
            "textFormat": {
                "bold": True
            }
        }
        worksheet.format(cell_range, fmt)
