import pandas as pd
from scipy.stats import kurtosis

def calculate_annual_kurtosis(worksheet):
    """Calculate kurtosis for the numerical columns and add them to the bottom of the worksheet."""
    values = worksheet.get_all_values()
    num_rows = len(values)
    num_cols = len(values[0])

    if num_rows > 1:
        kurtosis_values = ['', '', "ANNUAL KURTOSIS", worksheet.title]
        for col in range(4, num_cols):  # Start from the 4th column (index 3) to skip non-numeric columns
            col_values = []
            for row in range(1, num_rows):
                cell_value = values[row][col]
                if cell_value and cell_value.replace('.', '', 1).isdigit() and values[row][2] not in ["ANNUAL AVERAGE", "ANNUAL MEDIAN"]:
                    col_values.append(float(cell_value))
            
            if len(col_values) >= 2:
                kurt = kurtosis(col_values)
                kurtosis_values.append(f"{kurt:.2f}")
            else:
                kurtosis_values.append("0.0")

        # Remove existing kurtosis row if it exists
        if values[-1][2] == "ANNUAL KURTOSIS":
            worksheet.delete_rows(num_rows)

        # Add the new kurtosis row
        worksheet.append_row(kurtosis_values)
        
        # Apply bold format to the "ANNUAL KURTOSIS" row
        kurtosis_row_index = len(values) + 1  # New row index after appending
        cell_range = f'A{kurtosis_row_index}:Z{kurtosis_row_index}'  # Adjust the range as needed
        fmt = {
            "textFormat": {
                "bold": True
            }
        }
        worksheet.format(cell_range, fmt)
