import re  # Regular expressions library to search patterns in text
from bs4 import BeautifulSoup  # Library for parsing HTML and XML documents
import os  # Library for interacting with the operating system
import gspread  # Library for interacting with Google Sheets
from oauth2client.service_account import ServiceAccountCredentials  # Library for Google authentication
import time  # Library to add delays in the execution
import pandas as pd  # Library for data manipulation
from average_calculator import calculate_averages  # Import the calculate_averages function
from median_calculator import calculate_medians  # Import the calculate_medians function
from standard_deviation_calculator import calculate_annual_standard_deviation  # Import the calculate_annual_standard_deviation function
from range_calculator import calculate_range  # Import the calculate_range function
from annual_variance import calculate_annual_variance  # Import the calculate_annual_variance function
from interquartile_range_calculator import calculate_interquartile_range  # Import the calculate_interquartile_range function
from median_absolute_deviation_calculator import calculate_median_absolute_deviation  # Import the calculate_median_absolute_deviation function
from annual_skew_calculator import calculate_annual_skew  # Import the calculate_annual_skew function


def extract_percentage(text):
    """Helper function to extract percentage values from text."""
    match = re.search(r'\d+(\.\d+)?%', text)  # Search for a pattern that matches a number followed by a percentage sign
    return match.group().replace('%', '') if match else ''  # Return the matched percentage or an empty string if no match is found


def extract_numeric(text):
    """Helper function to extract numeric values from text."""
    match = re.search(r'\d+(\.\d+)?', text)  # Search for a pattern that matches a number
    return match.group().replace('p', '') if match else ''  # Return the matched number or an empty string if no match is found


def extract_company_code(soup):
    """Helper function to extract company code from the HTML content."""
    link = soup.find('a', class_='link-back')
    if link and 'href' in link.attrs:
        match = re.search(r'/Employer/(\w+)', link['href'])
        return match.group(1) if match else ''
    return ''


def scrape_pay_gap_data(html_content):
    soup = BeautifulSoup(html_content, 'html.parser')  # Parse the HTML content
    data = {}  # Dictionary to store the scraped data


    # Company Code
    data['Company Code'] = extract_company_code(soup)


    # Company Name
    company_name = soup.find('div', id='OrganisationName')  # Find the div element with the id 'OrganisationName'
    data['Company Name'] = company_name.text.strip() if company_name else ''  # Get the text, strip whitespace, or return '' if not found


    # Year
    title = soup.find('title').text  # Find the title element and get its text
    year_match = re.search(r'\d{4}', title)  # Search for a 4-digit year in the title
    data['Year'] = year_match.group() if year_match else ''  # Get the matched year or return '' if not found


    # Extract Median Hourly Pay Difference section
    hourly_rate_section = soup.find('section', id='HourlyRateInfo')  # Find the section element with the id 'HourlyRateInfo'
    if hourly_rate_section:
        spans = hourly_rate_section.find_all('span')  # Find all span elements within this section
        median_hourly_pay_diff = ""
        mean_hourly_pay_diff = ""


        for span in spans:
            if 'median hourly pay is' in span.text:  # Check if the span contains the median hourly pay information
                median_hourly_pay_diff = extract_numeric(span.text)  # Extract the numeric value
            if 'mean hourly pay is' in span.text:  # Check if the span contains the mean hourly pay information
                mean_hourly_pay_diff = extract_numeric(span.text)  # Extract the numeric value


        data['Median Hourly Pay Difference'] = median_hourly_pay_diff
        data['Mean Gender Pay Gap'] = mean_hourly_pay_diff


        # Extract £ Pay Men and £ Pay Women
        pay_women_text = hourly_rate_section.find('figure', id='MedianHourlyDiffChart').find('div', class_='govuk-chart-vert__caption--women')
        pay_men_text = hourly_rate_section.find('figure', id='MedianHourlyDiffChart').find('div', class_='govuk-chart-vert__caption--men')


        if pay_women_text and pay_men_text:
            pay_women_value = pay_women_text.get('data-chart-text').replace('p', '')  # Get the value from the data-chart-text attribute and remove 'p'
            pay_men_value = pay_men_text.get('data-chart-text')
            data['£ Pay Men'] = '1'
            data['£ Pay Women'] = str(float(pay_women_value.strip()) / 100)  # Convert to float, divide by 100, and convert back to string
        else:
            data['£ Pay Men'] = ''
            data['£ Pay Women'] = ''


    # Extract Pay Quartiles section
    quartiles_section = soup.find('section', id='PayQuartilesInfo')  # Find the section element with the id 'PayQuartilesInfo'
    if quartiles_section:
        quartiles = quartiles_section.find_all('figure')  # Find all figure elements within this section


        # Upper hourly pay quarter (highest paid)
        if len(quartiles) > 0:
            upper_quarter_women = extract_percentage(quartiles[0].find('div', class_='govuk-chart-horz__text--left').text)
            upper_quarter_men = extract_percentage(quartiles[0].find('div', class_='govuk-chart-horz__text--right').text)
            data['Upper Hourly Pay Quarter Women'] = upper_quarter_women
            data['Upper Hourly Pay Quarter Men'] = upper_quarter_men


        # Upper middle hourly pay quarter
        if len(quartiles) > 1:
            upper_middle_quarter_women = extract_percentage(quartiles[1].find('div', class_='govuk-chart-horz__text--left').text)
            upper_middle_quarter_men = extract_percentage(quartiles[1].find('div', class_='govuk-chart-horz__text--right').text)
            data['Upper Middle Hourly Pay Quarter Women'] = upper_middle_quarter_women
            data['Upper Middle Hourly Pay Quarter Men'] = upper_middle_quarter_men


        # Lower middle hourly pay quarter
        if len(quartiles) > 2:
            lower_middle_quarter_women = extract_percentage(quartiles[2].find('div', class_='govuk-chart-horz__text--left').text)
            lower_middle_quarter_men = extract_percentage(quartiles[2].find('div', class_='govuk-chart-horz__text--right').text)
            data['Lower Middle Hourly Pay Quarter Women'] = lower_middle_quarter_women
            data['Lower Middle Hourly Pay Quarter Men'] = lower_middle_quarter_men


        # Lower hourly pay quarter (lowest paid)
        if len(quartiles) > 3:
            lower_quarter_women = extract_percentage(quartiles[3].find('div', class_='govuk-chart-horz__text--left').text)
            lower_quarter_men = extract_percentage(quartiles[3].find('div', class_='govuk-chart-horz__text--right').text)
            data['Lower Hourly Pay Quarter Women %'] = lower_quarter_women
            data['Lower Hourly Pay Quarter Men %'] = lower_quarter_men


    # Extract Bonus Pay Gap section
    bonus_pay_gap_section = soup.find('section', id='BonusPayGap')  # Find the section element with the id 'BonusPayGap'
    if bonus_pay_gap_section:
        spans = bonus_pay_gap_section.find_all('span')  # Find all span elements within this section
        median_bonus_gap = ""
        mean_bonus_gap = ""


        for span in spans:
            if 'median bonus pay is' in span.text:  # Check if the span contains the median bonus pay information
                median_bonus_gap = extract_numeric(span.text)  # Extract the numeric value
            if 'mean bonus pay is' in span.text:  # Check if the span contains the mean bonus pay information
                mean_bonus_gap = extract_numeric(span.text)  # Extract the numeric value


        data['Median Bonus Pay Gap Difference %'] = median_bonus_gap
        data['Mean Bonus Pay Difference'] = mean_bonus_gap


        # Special handling for mean bonus pay difference
        mean_bonus_span = bonus_pay_gap_section.find('span', id='DiffMeanBonusPercent')
        if mean_bonus_span:
            mean_bonus_text = mean_bonus_span.find('span').text.strip().replace('%', '')  # Remove the '%' sign
            data['Mean Bonus Pay Difference'] = mean_bonus_text if mean_bonus_text else ''


        # Extract £ Bonus Pay Men and £ Bonus Pay Women
        bonus_pay_women_text = bonus_pay_gap_section.find('figure', id='MedianBonusDiffChart').find('div', class_='govuk-chart-vert__caption--women')
        bonus_pay_men_text = bonus_pay_gap_section.find('figure', id='MedianBonusDiffChart').find('div', class_='govuk-chart-vert__caption--men')
        if bonus_pay_women_text and bonus_pay_men_text:
            bonus_pay_women_value = bonus_pay_women_text.get('data-chart-text').replace('p', '').replace('£', '')  # Remove 'p' and '£'
            bonus_pay_men_value = bonus_pay_men_text.get('data-chart-text')
            data['£ Bonus Pay Men'] = '1'
            data['£ Bonus Pay Women'] = str(float(bonus_pay_women_value.strip()) / 100)  # Convert to float, divide by 100, and convert back to string
        else:
            data['£ Bonus Pay Men'] = ''
            data['£ Bonus Pay Women'] = ''


        # Extract Bonus Pay Received Men and Women
        bonus_received_men = bonus_pay_gap_section.find('span', id='MaleBonusPayText')
        bonus_received_women = bonus_pay_gap_section.find('span', id='FemaleBonusPayText')
        if bonus_received_men and bonus_received_women:
            data['Bonus Pay Received Men'] = extract_percentage(bonus_received_men.text)
            data['Bonus Pay Received Women'] = extract_percentage(bonus_received_women.text)
        else:
            data['Bonus Pay Received Men'] = ''
            data['Bonus Pay Received Women'] = ''


    return data


def update_google_sheet(sheet, data, year, company_id):
    """Helper function to update Google Sheet with data."""
    sheet_name = str(year)
    try:
        worksheet = sheet.worksheet(sheet_name)
    except gspread.exceptions.WorksheetNotFound:
        worksheet = sheet.add_worksheet(title=sheet_name, rows="100", cols="21")
        # Add headers to the new worksheet
        headers = [
            'Company ID', 'Company Code', 'Company Name', 'Year', 'Median Hourly Pay Difference %', 'Mean Gender Pay Gap %', '£ Pay Men', '£ Pay Women',
            'Upper Hourly Pay Quarter Women %', 'Upper Hourly Pay Quarter Men %', 'Upper Middle Hourly Pay Quarter Women %',
            'Upper Middle Hourly Pay Quarter Men %', 'Lower Middle Hourly Pay Quarter Women %', 'Lower Middle Hourly Pay Quarter Men %',
            'Lower Hourly Pay Quarter Women %', 'Lower Hourly Pay Quarter Men %', 'Median Bonus Pay Gap Difference %',
            'Mean Bonus Pay Difference %', '£ Bonus Pay Men', '£ Bonus Pay Women', 'Bonus Pay Received Men %', 'Bonus Pay Received Women %'
        ]
        worksheet.append_row(headers)


        # Apply bold format to headers
        cell_range = 'A1:Z1'  # Adjust the range as needed
        fmt = {
            "textFormat": {
                "bold": True
            }
        }
        worksheet.format(cell_range, fmt)


    # Remove existing average, median, range, standard deviation, variance, IQR, MAD, and skew rows if they exist
    existing_rows = worksheet.get_all_values()
    summary_labels = ["ANNUAL AVERAGE", "ANNUAL MEDIAN", "ANNUAL RANGE", "ANNUAL STANDARD DEVIATION", "ANNUAL VARIANCE", "ANNUAL IQR", "ANNUAL MAD", "ANNUAL SKEW"]
    row_indices_to_delete = [index for index, row in enumerate(existing_rows) if len(row) > 2 and row[2] in summary_labels]


    for index in sorted(row_indices_to_delete, reverse=True):
        worksheet.delete_rows(index + 1)


    # Append data to the worksheet
    row = [
        company_id,
        data.get('Company Code', ''),
        data.get('Company Name', ''),
        data.get('Year', ''),
        data.get('Median Hourly Pay Difference', ''),
        data.get('Mean Gender Pay Gap', ''),
        data.get('£ Pay Men', ''),
        data.get('£ Pay Women', ''),
        data.get('Upper Hourly Pay Quarter Women', ''),
        data.get('Upper Hourly Pay Quarter Men', ''),
        data.get('Upper Middle Hourly Pay Quarter Women', ''),
        data.get('Upper Middle Hourly Pay Quarter Men', ''),
        data.get('Lower Middle Hourly Pay Quarter Women', ''),
        data.get('Lower Middle Hourly Pay Quarter Men', ''),
        data.get('Lower Hourly Pay Quarter Women %', ''),
        data.get('Lower Hourly Pay Quarter Men %', ''),
        data.get('Median Bonus Pay Gap Difference %', ''),
        data.get('Mean Bonus Pay Difference', ''),
        data.get('£ Bonus Pay Men', ''),
        data.get('£ Bonus Pay Women', ''),
        data.get('Bonus Pay Received Men', ''),
        data.get('Bonus Pay Received Women', '')
    ]


    # Convert all items in the row to standard Python types
    row = [item.item() if isinstance(item, (pd.Int64Dtype, pd.Float64Dtype)) else item for item in row]


    # Ensure all values are strings
    row = [str(item) for item in row]


    # Check if the row already exists
    if row not in existing_rows:
        worksheet.append_row(row)


    # Add a delay to avoid exceeding the quota limit
    time.sleep(2)


    # Calculate and add averages
    calculate_averages(worksheet)


    # Add a delay to avoid exceeding the quota limit
    time.sleep(2)


    # Calculate and add medians
    calculate_medians(worksheet)


    # Add a delay to avoid exceeding the quota limit
    time.sleep(2)


    # Calculate and add range
    calculate_range(worksheet)


    # Add a delay to avoid exceeding the quota limit
    time.sleep(2)


    # Calculate and add standard deviations
    calculate_annual_standard_deviation(worksheet)


    # Add a delay to avoid exceeding the quota limit
    time.sleep(2)


    # Calculate and add variance
    calculate_annual_variance(worksheet)


    # Add a delay to avoid exceeding the quota limit
    time.sleep(2)


    # Calculate and add interquartile range
    calculate_interquartile_range(worksheet)


    # Add a delay to avoid exceeding the quota limit
    time.sleep(2)


    # Calculate and add median absolute deviation
    calculate_median_absolute_deviation(worksheet)


    # Add a delay to avoid exceeding the quota limit
    time.sleep(2)


    # Calculate and add skew
    calculate_annual_skew(worksheet)


def main():
    scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
    creds = ServiceAccountCredentials.from_json_keyfile_name("service_account.json", scope)
    client = gspread.authorize(creds)


    sheet = client.open("Gender Pay Gap Data")


    # Load existing company codes and IDs
    company_ids = {}
    all_worksheets = sheet.worksheets()
    for worksheet in all_worksheets:
        rows = worksheet.get_all_values()
        for row in rows[1:]:  # Skip header row
            company_code = row[1]  # Assuming Company Code is in the second column
            company_id = row[0]  # Assuming Company ID is in the first column
            company_ids[company_code] = company_id


    # Load the Excel data
    excel_file_path = 'C:\\Python Files\\IDNuclear_2\\Test Data\\MS\\Gender_Pay_Gap_Data_2017.xlsx'  # Adjust the path as necessary
    df = pd.read_excel(excel_file_path)
    df = df.set_index('EmployerName')  # Assuming EmployerName is the column with company names


    # Print columns of the DataFrame to check the column names
    print("Columns in the DataFrame:", df.columns)


    # Prompt the user to input the directory path
    while True:
        directory_path = input("Please enter the directory path containing the HTML files: ")
        if os.path.isdir(directory_path):
            break
        else:
            print("Invalid directory path. Please try again.")


    for file_name in os.listdir(directory_path):
        if file_name.endswith(".html"):
            file_path = os.path.join(directory_path, file_name)
            with open(file_path, "r", encoding='utf-8') as file:
                html_content = file.read()


            pay_gap_data = scrape_pay_gap_data(html_content)
            company_name = pay_gap_data.get('Company Name', '')


            if company_name in df.index:
                company_id = df.loc[company_name, 'EmployerId']  # Fetch EmployerId from the Excel file
                pay_gap_data['Company ID'] = company_id
                company_code = company_ids.get(pay_gap_data['Company Code'], '')


                print(f"\nData for {file_name}:")
                for key, value in pay_gap_data.items():
                    print(f"{key}: {value}")
                print("\n")


                # Update Google Sheet with the scraped data
                year = pay_gap_data.get('Year', '')
                if year != '':
                    update_google_sheet(sheet, pay_gap_data, year, company_id)


if __name__ == "__main__":
    main()


