import pandas as pd
import numpy as np

def calculate_interquartile_range(worksheet):
    """Calculate Interquartile Range (IQR) for the numerical columns and add them to the bottom of the worksheet."""
    values = worksheet.get_all_values()
    num_rows = len(values)
    num_cols = len(values[0])

    if num_rows > 1:
        iqr_row = ['', '', "ANNUAL IQR", worksheet.title]
        
        for col in range(4, num_cols):
            col_values = [float(values[row][col]) for row in range(1, num_rows) if values[row][col] and values[row][2] not in ["ANNUAL AVERAGE", "ANNUAL MEDIAN", "ANNUAL RANGE", "ANNUAL STANDARD DEVIATION", "ANNUAL VARIANCE", "ANNUAL IQR"]]
            if col_values:
                q75, q25 = np.percentile(col_values, [75, 25])
                iqr = q75 - q25
                iqr_row.append(f"{iqr:.2f}")
            else:
                iqr_row.append("")

        # Remove existing IQR row if it exists
        existing_rows = worksheet.get_all_values()
        while existing_rows and (existing_rows[-1][2] == "ANNUAL IQR"):
            worksheet.delete_rows(len(existing_rows))
            existing_rows = worksheet.get_all_values()

        # Add the new IQR row
        worksheet.append_row(iqr_row)
        
        # Apply bold format to the "ANNUAL IQR" row
        iqr_row_index = len(existing_rows) + 1  # New row index after appending
        cell_range = f'A{iqr_row_index}:Z{iqr_row_index}'  # Adjust the range as needed
        fmt = {
            "textFormat": {
                "bold": True
            }
        }
        worksheet.format(cell_range, fmt)
