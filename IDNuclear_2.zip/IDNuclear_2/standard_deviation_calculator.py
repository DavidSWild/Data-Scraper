import math

def calculate_annual_standard_deviation(worksheet):
    """Calculate standard deviation for the numerical columns and add them to the bottom of the worksheet."""
    values = worksheet.get_all_values()
    num_rows = len(values)
    num_cols = len(values[0])

    if num_rows > 1:
        standard_deviations = ['', '', "ANNUAL STANDARD DEVIATION", worksheet.title]
        for col in range(4, num_cols):
            col_values = [float(values[row][col]) for row in range(1, num_rows) if values[row][col] and values[row][2] not in ["ANNUAL AVERAGE", "ANNUAL MEDIAN"]]
            if col_values:
                mean = sum(col_values) / len(col_values)
                variance = sum((x - mean) ** 2 for x in col_values) / len(col_values)
                stddev = math.sqrt(variance)
                standard_deviations.append(f"{stddev:.2f}")
            else:
                standard_deviations.append("")

        # Remove existing standard deviation row if it exists
        if values[-1][2] == "ANNUAL STANDARD DEVIATION":
            worksheet.delete_rows(num_rows)

        # Add the new standard deviation row
        worksheet.append_row(standard_deviations)
        
        # Apply bold format to the "ANNUAL STANDARD DEVIATION" row
        stddev_row_index = len(values) + 1  # New row index after appending
        cell_range = f'A{stddev_row_index}:Z{stddev_row_index}'  # Adjust the range as needed
        fmt = {
            "textFormat": {
                "bold": True
            }
        }
        worksheet.format(cell_range, fmt)
