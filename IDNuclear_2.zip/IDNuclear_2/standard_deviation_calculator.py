import math

def calculate_annual_standard_deviation(worksheet):
    """Calculate standard deviation for the numerical columns and add them to the bottom of the worksheet."""
    values = worksheet.get_all_values()
    num_rows = len(values)
    num_cols = len(values[0])

    if num_rows > 1:
        standard_deviations = ['', '', "ANNUAL STANDARD DEVIATION", worksheet.title]
        for col in range(4, num_cols):  # Start from the 4th column (index 4) to skip non-numeric columns
            col_values = []
            for row in range(1, num_rows):
                cell_value = values[row][col]
                # Ensure the cell value is a valid number and not a summary row
                if cell_value.replace('.', '', 1).isdigit() and values[row][2] not in ["ANNUAL AVERAGE", "ANNUAL MEDIAN", "ANNUAL RANGE", "ANNUAL STANDARD DEVIATION", "ANNUAL VARIANCE", "ANNUAL IQR", "ANNUAL MAD", "ANNUAL SKEW"]:
                    col_values.append(float(cell_value))
            
            # Check if there are at least 2 entries
            if len(col_values) >= 2:
                mean = sum(col_values) / len(col_values)
                variance = sum((x - mean) ** 2 for x in col_values) / len(col_values)
                stddev = math.sqrt(variance)
                standard_deviations.append(f"{stddev:.2f}")
            else:
                standard_deviations.append("0.0")

        # Remove existing standard deviation row if it exists
        if values[-1][2] == "ANNUAL STANDARD DEVIATION":
            worksheet.delete_rows(num_rows)

        # Add the new standard deviation row
        worksheet.append_row(standard_deviations)
        
        # Apply bold format to the "ANNUAL STANDARD DEVIATION" row
        stddev_row_index = len(values) + 1  # New row index after appending
        cell_range = f'A{stddev_row_index}:Z{stddev_row_index}'  # Adjust the range as needed
        fmt = {
            "textFormat": {
                "bold": True
            }
        }
        worksheet.format(cell_range, fmt)
