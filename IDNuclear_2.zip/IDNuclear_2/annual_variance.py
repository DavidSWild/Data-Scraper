import math

def calculate_annual_variance(worksheet):
    """Calculate the variance for the numerical columns and add them to the bottom of the worksheet."""
    values = worksheet.get_all_values()
    num_rows = len(values)
    num_cols = len(values[0])

    if num_rows > 1:
        variances = ['', '', "ANNUAL VARIANCE", worksheet.title]
        for col in range(4, num_cols):
            col_values = [float(values[row][col]) for row in range(1, num_rows) if values[row][col] and values[row][2] not in ["ANNUAL AVERAGE", "ANNUAL MEDIAN", "ANNUAL RANGE", "ANNUAL STANDARD DEVIATION"]]
            if col_values:
                mean = sum(col_values) / len(col_values)
                variance = sum((x - mean) ** 2 for x in col_values) / len(col_values)
                variances.append(f"{variance:.2f}")
            else:
                variances.append("")

        # Remove existing variance row if it exists
        if values[-1][2] == "ANNUAL VARIANCE":
            worksheet.delete_rows(num_rows)

        # Add the new variance row
        worksheet.append_row(variances)
        
        # Apply bold format to the "ANNUAL VARIANCE" row
        variance_row_index = len(values) + 1  # New row index after appending
        cell_range = f'A{variance_row_index}:Z{variance_row_index}'  # Adjust the range as needed
        fmt = {
            "textFormat": {
                "bold": True
            }
        }
        worksheet.format(cell_range, fmt)
