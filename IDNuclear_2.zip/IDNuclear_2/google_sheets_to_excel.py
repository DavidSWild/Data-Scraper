import msal
import requests

# Azure AD credentials
client_id = 'ca4133cd-c611-4979-ba14-3a800b814229'
tenant_id = '14d47268-950e-4d0e-b4f9-6f7083242b67'

# Public client application
app = msal.PublicClientApplication(client_id, authority=f"https://login.microsoftonline.com/{tenant_id}")

# Get authorization code (you'll need to visit the URL and log in)
flow = app.initiate_device_flow(scopes=["Files.ReadWrite.All", "User.Read"])
if "user_code" in flow:
    print(flow["message"])
    input("Press Enter after completing login with the code...")

# Acquire token using the device flow
result = app.acquire_token_by_device_flow(flow)
if "access_token" in result:
    access_token = result['access_token']
else:
    print("Failed to obtain access token.")
    print(result)
    exit()
