import gspread

def calculate_range(worksheet):
    """Calculate the range for the numerical columns and add them to the worksheet."""
    values = worksheet.get_all_values()
    num_rows = len(values)
    num_cols = len(values[0])

    if num_rows > 1:
        # Extract the year from the second row (assuming the year is consistent in the column)
        year = values[1][3] if num_cols > 3 else ''
        ranges = ['', '', "ANNUAL RANGE", year]
        for col in range(4, num_cols):
            col_values = [float(value) for value in [values[row][col] for row in range(1, num_rows) if values[row][col].replace('.', '', 1).isdigit()]]
            if col_values:
                col_range = max(col_values) - min(col_values)
                ranges.append(f"{col_range:.2f}")
            else:
                ranges.append("")

        # Insert the new range row before the "ANNUAL STANDARD DEVIATION" row
        if values[-1][2] == "ANNUAL STANDARD DEVIATION":
            worksheet.insert_row(ranges, num_rows)
        else:
            worksheet.append_row(ranges)

        # Apply bold format to the "ANNUAL RANGE" row
        range_row_index = num_rows if values[-1][2] != "ANNUAL STANDARD DEVIATION" else num_rows - 1
        cell_range = f'A{range_row_index + 1}:Z{range_row_index + 1}'  # Adjust the range as needed
        fmt = {
            "textFormat": {
                "bold": True
            }
        }
        worksheet.format(cell_range, fmt)
